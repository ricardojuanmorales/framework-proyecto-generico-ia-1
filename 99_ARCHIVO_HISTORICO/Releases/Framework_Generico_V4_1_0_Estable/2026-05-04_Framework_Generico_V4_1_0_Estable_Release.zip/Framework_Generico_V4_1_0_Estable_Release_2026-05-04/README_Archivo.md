# Archivo de Release
## Framework Genérico V4.1.0-estable

**Fecha:** 2026-05-04  
**Estado:** Paquete de release estable documental  
**Base histórica:** Framework Genérico V4.0.0  
**Nivel:** N3 — Avanzado  

## Contenido

```text
documentos/
wiki_prioritaria/
archive_manifest.json
README_Archivo.md
```

## Propósito

Preservar los documentos esenciales de Framework Genérico V4.1.0-estable, incluyendo gobernanza, índices, matrices, checks, wiki prioritaria, release notes y protocolos.

## Advertencia

Este release declara estabilidad documental, metodológica y de gobernanza. No declara automatización institucional completa ni auditoría N4.

## Uso recomendado

1. Abrir Release Notes.
2. Abrir README Framework V4.1.0.
3. Revisar Índice Maestro.
4. Consultar Manifest JSON.
5. Usar Matriz N1-N4, Gates y CHECKS.
6. Usar Wiki prioritaria para adopción humana.
7. Mantener V4.0.0 archivada como base histórica.
