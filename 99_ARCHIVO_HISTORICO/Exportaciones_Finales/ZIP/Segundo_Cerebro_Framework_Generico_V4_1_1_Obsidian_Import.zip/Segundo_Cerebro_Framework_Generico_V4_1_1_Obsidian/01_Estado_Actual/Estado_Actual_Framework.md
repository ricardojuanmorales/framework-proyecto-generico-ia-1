# Estado Actual — Framework Genérico

## Versión activa

```text
Framework Genérico V4.1.1 — Repositorio Modelo Operativo
```

## Última versión estable

```text
Framework Genérico V4.1.0-estable
```

## Base histórica

```text
Framework Genérico V4.0.0
```

## Estado breve

- V4.1.0-estable fue aprobada.
- V4.1.1 organiza el repositorio para GitHub.
- El segundo cerebro se activa en Obsidian.
- El modelo operativo es Triple Memoria + Issues ligeros.

## Próximo movimiento

[[04_Issues/Issues_Iniciales_V4_1_1]]
