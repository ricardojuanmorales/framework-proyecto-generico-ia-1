# Importar en Obsidian — Segundo Cerebro Framework Genérico V4.1.1

## Cómo usar este vault

1. Descarga y descomprime el ZIP.
2. Abre Obsidian.
3. Selecciona **Open folder as vault**.
4. Escoge la carpeta `Segundo_Cerebro_Framework_Generico_V4_1_1_Obsidian`.
5. Abre [[00_Dashboard/Dashboard_Framework_Generico_V4_1_1]].

## Conexión con GitHub

Reemplaza todas las apariciones de:

```text
REEMPLAZAR_CON_URL_DEL_REPOSITORIO
```

por la URL real del repositorio.

## Regla

GitHub es la fuente oficial.  
Obsidian es la cabina de mando interpretativa.
