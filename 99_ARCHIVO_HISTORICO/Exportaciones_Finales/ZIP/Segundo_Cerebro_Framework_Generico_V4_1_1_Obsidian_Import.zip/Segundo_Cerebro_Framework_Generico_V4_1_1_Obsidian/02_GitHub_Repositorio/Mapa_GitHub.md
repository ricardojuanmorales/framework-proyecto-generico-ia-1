# Mapa GitHub — Framework Genérico V4.1.1

## URL del repositorio

`REEMPLAZAR_CON_URL_DEL_REPOSITORIO`

## Cartapacios principales

```text
00_CONTROL_MAESTRO/
02_ARQUITECTURA_CONCEPTUAL/
03_METODOLOGIA_Y_FLUJO_DE_TRABAJO/
04_GOBERNANZA_ETICA_Y_RIESGOS/
09_IA_AGENTES_Y_COPILOTOS/
15_EVALUACION_CALIDAD_Y_AUDITORIA/
18_DOCUMENTACION_ACTIVA/
21_WIKI_DOCUMENTACION_HUMANA/
99_ARCHIVO_HISTORICO/
```

## Documentos que se abren primero

- README.md
- manifest_repositorio_v4_1_1.json
- TREE_REPOSITORIO_V4_1_1.txt
- Record V4.1.1
- Primer de continuidad más reciente

## Regla

No duplicar documentos oficiales completos en Obsidian. Enlazar y resumir.
