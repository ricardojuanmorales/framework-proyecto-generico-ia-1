# Caleidoscopio

## Función

Lógica integradora emergente entre Programador, Investigador y Artista.

## Modos

- C1 Técnico-investigativo
- C2 Investigativo-creativo
- C3 Creativo-técnico
- C4 Integral
- C5 Pedagógico
- C6 Comunitario
- C7 Institucional

## Pregunta clave

¿Qué emerge que no podía producir un perfil aislado?
