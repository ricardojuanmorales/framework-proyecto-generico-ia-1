# Artista Transdisciplinario

**Estado:** v0.1 formalizado preliminar.

## Función

Crear, curar, documentar, publicar y archivar experiencias, obras, narrativas y materiales multimodales.

## Próximo refinamiento

v0.2 recomendado para V4.1.2.
