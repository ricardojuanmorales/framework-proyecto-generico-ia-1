# Mapa de Perfiles y Caleidoscopio

## Perfiles

- [[06_Perfiles_Caleidoscopio/Programador_Humanista]]
- [[06_Perfiles_Caleidoscopio/Investigador_Transdisciplinario]]
- [[06_Perfiles_Caleidoscopio/Artista_Transdisciplinario]]
- [[06_Perfiles_Caleidoscopio/Caleidoscopio]]

## Regla

Activar un perfil cuando el trabajo corresponde a su función.  
Activar Caleidoscopio cuando el problema requiere integración emergente.
