# Investigador Transdisciplinario

**Estado:** v0.1 formalizado preliminar.

## Función

Problematizar, investigar, gestionar fuentes, producir evidencia, validar y transferir conocimiento.

## Próximo refinamiento

v0.2 recomendado para V4.1.2.
