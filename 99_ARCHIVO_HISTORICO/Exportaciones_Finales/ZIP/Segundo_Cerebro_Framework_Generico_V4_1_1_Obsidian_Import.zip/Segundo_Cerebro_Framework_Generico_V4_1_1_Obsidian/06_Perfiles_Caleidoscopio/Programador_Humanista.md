# Programador Humanista

**Estado:** v0.2 cerrado funcional.

## Función

Construcción técnica responsable, documentación, pruebas, seguridad, mantenimiento y transferencia.

## Usar cuando

- Hay código.
- Hay repositorio.
- Hay automatización.
- Hay arquitectura técnica.
- Hay pruebas o despliegue.
