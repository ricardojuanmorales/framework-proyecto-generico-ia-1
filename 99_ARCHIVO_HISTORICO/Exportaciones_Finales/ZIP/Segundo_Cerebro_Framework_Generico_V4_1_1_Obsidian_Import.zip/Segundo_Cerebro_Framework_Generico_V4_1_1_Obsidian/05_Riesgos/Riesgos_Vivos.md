# Riesgos Vivos

| Riesgo | Estado | Mitigación |
|---|---|---|
| Desfase GitHub / Obsidian | Medio | Enlazar, no duplicar |
| Issues sin cierre | Medio | Usar criterios de cierre |
| Automatización prematura | Alto | Mantener bloqueo hasta N4 |
| Wiki secundaria pendiente | Medio | Crear Issue D-A49 |
| Piloto pendiente | Medio | Crear Issue D-A50 |

## Regla

Todo riesgo medio o alto debe vincularse a un Issue o decisión.
