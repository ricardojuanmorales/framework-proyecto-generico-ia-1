# Wiki Pendiente

## Prioridad alta completada

- Home Framework V4.1.0
- Guía Inicio Rápido
- Guía N1-N4
- Guía Gates/CHECKS
- Guía Caleidoscopio C1-C7

## Pendiente V4.1.2

- Guías Programador Humanista
- Guías Investigador Transdisciplinario
- Guías Artista Transdisciplinario
- Guías Caleidoscopio ampliadas
- Glosario V4.1.1
- Guía de adopción por escenarios
