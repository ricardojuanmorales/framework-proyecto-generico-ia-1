# Archivo Obsidian

Usar este cartapacio para notas interpretativas obsoletas o cerradas.

Los documentos oficiales deben archivarse en GitHub, no aquí.
