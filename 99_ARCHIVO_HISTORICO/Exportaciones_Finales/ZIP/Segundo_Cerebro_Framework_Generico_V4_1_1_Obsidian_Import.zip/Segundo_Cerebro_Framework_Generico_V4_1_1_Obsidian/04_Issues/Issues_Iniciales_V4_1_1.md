# Issues Iniciales V4.1.1

## Lote inicial sugerido

| Issue | Título | Nivel | Estado |
|---|---|---|---|
| D-A46 | Crear Dashboard del Segundo Cerebro | N2 | En curso |
| D-A47 | Crear plantilla de Issue ligero | N2 | En curso |
| D-A48 | Crear vault inicial de Obsidian | N2 | En curso |
| D-A49 | Crear wiki secundaria V4.1.1 | N3 | Pendiente |
| D-A50 | Ejecutar primer piloto práctico | N3 | Pendiente |
| D-A51 | Crear matriz de riesgos ampliada | N3 | Pendiente |
| D-A52 | Refinar Investigador Transdisciplinario v0.2 | N3 | Pendiente |
| D-A53 | Refinar Artista Transdisciplinario v0.2 | N3 | Pendiente |
| D-A54 | Probar Caleidoscopio C1-C7 | N3 | Pendiente |

## En GitHub

Crear cada Issue usando la plantilla:

[[09_Templates/Template_Issue_Ligero]]
