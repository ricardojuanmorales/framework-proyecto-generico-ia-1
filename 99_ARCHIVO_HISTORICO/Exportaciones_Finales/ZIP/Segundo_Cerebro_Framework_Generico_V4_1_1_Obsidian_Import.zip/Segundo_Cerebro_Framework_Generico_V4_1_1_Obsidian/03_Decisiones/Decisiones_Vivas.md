# Decisiones Vivas

## Decisión de modelo operativo

```text
D-A45 — Adoptar el Modelo Triple Memoria Operativa + Issues ligeros como sistema de continuidad, monitoreo y actualización del Framework Genérico V4.1.1.
```

## Decisiones recientes

| ID | Decisión | Estado |
|---|---|---|
| D-A43 | Aprobar V4.1.0-estable | Ejecutada |
| D-A44 | Abrir V4.1.1 repositorio modelo | Ejecutada |
| D-A45 | Adoptar Triple Memoria + Issues ligeros | En implementación |
| D-A46 | Crear Dashboard Segundo Cerebro | En curso |
| D-A47 | Crear plantilla Issue ligero | En curso |
| D-A48 | Crear vault Obsidian inicial | En curso |

## Próximas decisiones posibles

- D-A49 — Crear wiki secundaria.
- D-A50 — Ejecutar piloto práctico.
- D-A51 — Crear matriz de riesgos ampliada.
